package ru.mipt.snp.web.gwt.client.components;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.*;
import ru.mipt.snp.web.gwt.client.LoginMessages;
import ru.mipt.snp.web.gwt.client.utils.ComponentUtils;

/**
 * <p>User data widget</p>
 *
 * @author Maxim Galushka
 * @since 03/05/2009  13:11
 */
public class UserAnthropometricDataWidget extends DecoratorPanel{
    public static final LoginMessages messages = GWT.create(LoginMessages.class);

    private TextBox growthTextBox;
    private TextBox weightTextBox;
    private TextBox neckGirthTextBox;
    private TextBox bicepsGirthTextBox;
    private TextBox chestGirthTextBox;
    private TextBox waistGirthTextBox;
    private TextBox thighGirthTextBox;
    private TextBox drumstickGirthTextBox;

    private FlexTable layout;
    private FlexTable.FlexCellFormatter cellFormatter;

    public UserAnthropometricDataWidget() {
        this.setWidth("400px");

        layout = new FlexTable();
//        layout.setBorderWidth(1);
        layout.setWidth("100%");
        layout.setCellSpacing(6);
        cellFormatter = layout.getFlexCellFormatter();

        layout.setHTML(0, 0, messages.dataTitle());
        cellFormatter.setColSpan(0, 0, 2);
        cellFormatter.setHorizontalAlignment(0, 0, HasHorizontalAlignment.ALIGN_CENTER);

        growthTextBox = updateLayout(1, messages.dataGrowth());
        weightTextBox = updateLayout(2, messages.dataWeight());
        neckGirthTextBox = updateLayout(3, messages.dataNeckGirth());
        bicepsGirthTextBox = updateLayout(4, messages.dataBicepsGirth());
        chestGirthTextBox = updateLayout(5, messages.dataChestGirth());
        waistGirthTextBox = updateLayout(6, messages.dataWaistGirth());
        thighGirthTextBox = updateLayout(7, messages.dataThighGirth());
        drumstickGirthTextBox = updateLayout(8, messages.dataDrumstickGirth());

        cellFormatter.setColSpan(9, 0, 2);
        Button saveDataButton = buildSaveDataButton();
        cellFormatter.setHorizontalAlignment(9, 0, HasHorizontalAlignment.ALIGN_CENTER);
        layout.setWidget(9, 0, saveDataButton);

        this.setWidget(layout);
    }

    private Button buildSaveDataButton() {
        return new Button(messages.dataSaveButtonTitle(), new ClickListener(){
            public void onClick(Widget sender) {
                
                AnthropometricDataModel model = new AnthropometricDataModel();
                // TODO: implement logic
            }
        });
    }

    private TextBox updateLayout(int row, String nameLabel){
       layout.setHTML(row, 0, nameLabel);
        TextBox controlTextBox = ComponentUtils.buildStandardTextBox(null, false);
        cellFormatter.setHorizontalAlignment(row, 1, HasHorizontalAlignment.ALIGN_CENTER);
        layout.setWidget(row, 1, controlTextBox);
        return controlTextBox;
    }
}
