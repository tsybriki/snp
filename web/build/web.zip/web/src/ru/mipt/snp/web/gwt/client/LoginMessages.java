package ru.mipt.snp.web.gwt.client;

import com.google.gwt.i18n.client.Messages;

/**
 * <p>Application error/inform messages</p>
 *
 * @author Maxim Galushka
 */
public interface LoginMessages extends Messages {

    @Key("text")
    String text();

    @Key("left.menu.profile")
    String leftMenuProfile();

    @Key("left.menu.data")
    String leftMenuData();

    @Key("settings.firstname")
    String settingsFirstName();

    @Key("settings.lastname")
    String settingsLastName();

    @Key("settings.title")
    String settingsTitle();

    @Key("settings.saveButtonLabel")
    String settingsSaveButtonLabel();

    @Key("settings.savedMessage")
    String settingsSavedMessage();

    @Key("settings.savedErrorMessage")
    String settingsSavedErrorMessage();

    @Key("settings.emptyFormFieldError")
    String settingsEmptyFormFieldError(String p0);

    @Key("settings.errorLoadingSettingsFromDatabase")
    String settingsErrorLoadingSettingsFromDatabase();

    @Key("left.menu.logout")
    String leftMenuLogout();

    @Key("settings.oldPassword")
    String settingsOldPassword();

    @Key("settings.newPassword")
    String settingsNewPassword();

    @Key("settings.repeatNewPassword")
    String settingsRepeatNewPassword();

    @Key("settings.saveNewPasswordLabel")
    String settingsSaveNewPasswordLabel();

    @Key("settings.passwordsMismatchError")
    String settingsPasswordsMismatchError();

    @Key("settings.savedPasswordErrorMessage")
    String settingsSavedPasswordErrorMessage();

    @Key("settings.oldPasswordIncorrectError")
    String settingsOldPasswordIncorrectError();

    @Key("settings.passwordSuccessfullySavedMessage")
    String settingsPasswordSuccessfullySavedMessage();

    @Key("settings.changePassword")
    String settingsChangePassword();

    @Key("data.title")
    String dataTitle();

    @Key("data.growth")
    String dataGrowth();

    @Key("data.weight")
    String dataWeight();

    @Key("data.neckGirth")
    String dataNeckGirth();

    @Key("data.bicepsGirth")
    String dataBicepsGirth();

    @Key("data.chestGirth")
    String dataChestGirth();

    @Key("data.waistGirth")
    String dataWaistGirth();

    @Key("data.thighGirth")
    String dataThighGirth();

    @Key("data.drumstickGirth")
    String dataDrumstickGirth();

    @Key("data.saveButtonTitle")
    String dataSaveButtonTitle();

    @Key("data.incorrectFormatErrorMessage")
    String dataIncorrectFormatErrorMessage(String p0);

    @Key("settings.gender")
    String settingsGender();

    @Key("settings.male")
    String settingsMale();

    @Key("settings.female")
    String settingsFemale();

//    @Key("settings.months")
//    String[] settingsMonths();

    @Key("settings.dateOfBirth")
    String settingsDateOfBirth();

    @Key("settings.calendar")
    String settingsCalendar();
}
