package ru.mipt.snp.web.gwt.client.components;

import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * <p>UI model for storing/retrieving changing user password data</p>
 *
 * @author Maxim Galushka
 * @since 03/12/2009  17:50
 */
public class UserPasswordModel implements IsSerializable{

    private String oldPassword;
    private String newPassword;
    private String repeatNewPassword;

    public UserPasswordModel() {
    }

    public UserPasswordModel(String newPassword) {
        this.newPassword = newPassword;
        this.repeatNewPassword = newPassword;
    }

    public UserPasswordModel(String oldPassword, String newPassword, String repeatNewPassword) {
        this.oldPassword = oldPassword;
        this.newPassword = newPassword;
        this.repeatNewPassword = repeatNewPassword;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getRepeatNewPassword() {
        return repeatNewPassword;
    }

    public void setRepeatNewPassword(String repeatNewPassword) {
        this.repeatNewPassword = repeatNewPassword;
    }
}
