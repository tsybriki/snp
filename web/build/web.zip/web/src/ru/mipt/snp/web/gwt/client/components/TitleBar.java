package ru.mipt.snp.web.gwt.client.components;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import ru.mipt.snp.web.gwt.client.ApplicationMessages;

/**
 * <p></p>
 *
 * @author Kirill Tsibriy
 * @since 03.05.2009
 */
public class TitleBar extends Composite {
    private static final ApplicationMessages appMessages = GWT.create(ApplicationMessages.class);

    public TitleBar() {
        final HorizontalPanel container = new HorizontalPanel();
        container.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);

        container.add(new HTML("<h1>" + appMessages.applicationTitle() + "</h1>"));

        this.initWidget(container);
    }
}
