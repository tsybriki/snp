package ru.mipt.snp.web.gwt.client.models;

import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * <p>UI model bean represents user settings</p>
 *
 * @author Maxim Galushka
 * @since 03/05/2009  14:24
 */
public class UserSettingsModel implements IsSerializable {

    private String firstName;
    private String lastName;

    public UserSettingsModel() {
    }

    public UserSettingsModel(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
