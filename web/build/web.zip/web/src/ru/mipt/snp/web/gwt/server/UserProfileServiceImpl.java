package ru.mipt.snp.web.gwt.server;

import ru.mipt.snp.dao.ProfileDao;
import ru.mipt.snp.domain.User;
import ru.mipt.snp.domain.UserDetailsImpl;
import ru.mipt.snp.logic.SecurityLogic;
import ru.mipt.snp.logic.ProfileLogic;
import ru.mipt.snp.web.gwt.client.UserProfileService;
import ru.mipt.snp.web.gwt.client.components.UserPasswordModel;
import ru.mipt.snp.web.gwt.client.models.UserSettingsModel;


/**
 * <p>Client interface uses for operating with profile data</p>
 *
 * @author Maxim Galushka
 * @since 03/05/2009  14:06
 */
public class UserProfileServiceImpl implements UserProfileService {

    private ProfileLogic profileLogic;
    private SecurityLogic securityLogic;

    public void updateUserSettings(UserSettingsModel model) {
        User user = securityLogic.getUserDetailsFromContext().getUser();
        user.setFirstName(model.getFirstName());
        user.setLastName(model.getLastName());
        profileLogic.updateUser(user);
    }

    public UserSettingsModel getUserSettings() {
        UserDetailsImpl impl = securityLogic.getUserDetailsFromContext();
        return (impl != null) ? new UserSettingsModel(impl.getUser().getFirstName(), impl.getUser().getPassword()) : null;
    }

    public void updateUserPassword(UserPasswordModel passwordModel) {
        User user = securityLogic.getUserDetailsFromContext().getUser();
        user.setPassword(passwordModel.getNewPassword());
        profileLogic.updateUser(user);
    }

    public UserPasswordModel getUserPasswordModel() {
        UserDetailsImpl impl = securityLogic.getUserDetailsFromContext();
        return (impl != null) ? new UserPasswordModel(impl.getUser().getPassword()) : null;
    }

    public void setSecurityLogic(SecurityLogic securityLogic) {
        this.securityLogic = securityLogic;
    }

    public void setProfileLogic(ProfileLogic profileLogic) {
        this.profileLogic = profileLogic;
    }
}
