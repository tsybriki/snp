package ru.mipt.snp.web.gwt.client.components;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.RootPanel;
import ru.mipt.snp.web.gwt.client.LoginMessages;
import ru.mipt.snp.web.gwt.client.utils.NativeUtils;

/**
 * <p>Application menu UI widget</p>
 *
 * @author Maxim Galushka
 * @since 03/05/2009  11:51
 */
public class SnpMenuWidget extends MenuBar{
    private static final String LOGOUT_PATH = "logout";
    public static final LoginMessages messages = GWT.create(LoginMessages.class);

    public SnpMenuWidget() {
        super(true);
        this.addItem(messages.leftMenuProfile(), new Command(){
            public void execute() {
                RootPanel rootPanel = RootPanel.get("contentWidget");
                rootPanel.clear();
                rootPanel.add(new UserSettingsWidget());
            }
        });

        this.addItem(messages.leftMenuData(), new Command() {
            public void execute() {
                RootPanel rootPanel = RootPanel.get("contentWidget");
                rootPanel.clear();
                rootPanel.add(new UserAnthropometricDataWidget());
            }
        });

        this.addItem(messages.leftMenuLogout(), new Command() {
            public void execute() {
                NativeUtils.redirect(GWT.getModuleBaseURL() + LOGOUT_PATH);
            }
        });
    }
}
