package ru.mipt.snp.web.gwt.client;

import com.google.gwt.user.client.rpc.ServiceDefTarget;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.core.client.GWT;

/**
 * <p></p>
 *
 * @author Kirill Tsibriy
 * @since Feb 16, 2009 1:23:11 PM
 */
public interface NameService extends RemoteService {
    String getName();

    /**
     * Utility/Convenience class.
     * Use NameService.App.getInstance() to access static instance of NameServiceAsync
     */
    public static class App {
        private static final NameServiceAsync ourInstance;

        static {
            ourInstance = (NameServiceAsync) GWT.create(NameService.class);
            ((ServiceDefTarget) ourInstance).setServiceEntryPoint(GWT.getModuleBaseURL() + "rpc/nameService.rpc");
        }

        public static NameServiceAsync getInstance() {
            return ourInstance;
        }
    }
}
