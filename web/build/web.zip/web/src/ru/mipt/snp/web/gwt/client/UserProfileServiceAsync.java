package ru.mipt.snp.web.gwt.client;

import com.google.gwt.user.client.rpc.AsyncCallback;
import ru.mipt.snp.web.gwt.client.models.UserSettingsModel;
import ru.mipt.snp.web.gwt.client.components.UserPasswordModel;

public interface UserProfileServiceAsync {

    /**
     * Stores user UI settings model in database
     *
     * @param data UI model bean with settings to store
     */
    void updateUserSettings(UserSettingsModel data, AsyncCallback async);

    /**
     * Retrieves user UI settings model from datatbase
     *
     * @return UI model bean with user settings
     */
    void getUserSettings(AsyncCallback<UserSettingsModel> async);

    /**
     * Stores new user UI password in database
     * @param passwordModel UI model bean with passwords data to store
     */
    void updateUserPassword(UserPasswordModel passwordModel, AsyncCallback async);

    /**
     * Retrieves user UI password model from database
     * @return UI model bean with passwords data
     */
    void getUserPasswordModel(AsyncCallback<UserPasswordModel> async);
}
