package ru.mipt.snp.web.gwt.client.utils;

import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;

/**
 * <p></p>
 *
 * @author Maxim Galushka
 * @since 03/13/2009  16:48
 */
public final class ComponentUtils {

    private static final int DEFAULT_TEXT_FIELD_LENGTH = 25;

    /**
     * Builds standard textbox component
     * @param size
     *@param isPassword if textbox should be passwordbox @return
     */
    public static TextBox buildStandardTextBox(Integer size, boolean isPassword){
        TextBox textBox;
        if(isPassword){
            textBox = new PasswordTextBox();
        }
        else{
            textBox = new TextBox();
        }
        textBox.setEnabled(isPassword);
        textBox.setVisibleLength((size==null || size==0) ? DEFAULT_TEXT_FIELD_LENGTH : size);
        return textBox;
    }

}
