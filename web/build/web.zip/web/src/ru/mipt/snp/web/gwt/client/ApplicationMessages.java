package ru.mipt.snp.web.gwt.client;

import com.google.gwt.i18n.client.Messages;

/**
 * <p></p>
 *
 * @author Kirill Tsibriy
 * @since 03.05.2009
 */
public interface ApplicationMessages extends Messages {
    String applicationTitle();
}
