package ru.mipt.snp.web.gwt.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.RootPanel;
import ru.mipt.snp.web.gwt.client.components.SnpMenuWidget;
import ru.mipt.snp.web.gwt.client.components.TitleBar;
import ru.mipt.snp.web.gwt.client.components.UserSettingsWidget;

/**
 * <p>Application entry point</p>
 *
 * @author Kirill Tsibriy
 * @since Feb 16, 2009 11:58:01 AM
 */
@SuppressWarnings({"GwtToHtmlReferences"})
public class Snp implements EntryPoint {
    public static final LoginMessages messages = GWT.create(LoginMessages.class);

    public void onModuleLoad() {
        final DockPanel outerLayout = new DockPanel();

        final TitleBar tBar = new TitleBar();
        tBar.setWidth("100%");
        outerLayout.add(tBar, DockPanel.NORTH);


        final SnpMenuWidget menu = new SnpMenuWidget();
        menu.setHeight("100%");
        outerLayout.add(menu, DockPanel.WEST);

        final UserSettingsWidget widget = new UserSettingsWidget();
        widget.setHeight("100%");
        widget.setWidth("100%");
        outerLayout.add(widget, DockPanel.CENTER);

        outerLayout.setWidth("100%");

        RootPanel.get().add(outerLayout);
    }
}
