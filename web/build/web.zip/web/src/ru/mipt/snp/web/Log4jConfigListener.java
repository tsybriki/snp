package ru.mipt.snp.web;

import org.apache.log4j.xml.DOMConfigurator;
import org.apache.log4j.Logger;

import javax.servlet.ServletContextListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContext;

/**
 * <p></p>
 *
 * Created by Kirill Tsibriy on 20.02.2009
 */
public class Log4jConfigListener implements ServletContextListener {
    public static final String LOG4J_CONFIG_FILE = "log4j.configuration";

    public void contextInitialized(ServletContextEvent servletContextEvent) {
        final ServletContext sc = servletContextEvent.getServletContext();
        DOMConfigurator.configure(sc.getRealPath(sc.getInitParameter(LOG4J_CONFIG_FILE)));
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent) {
    }
}
