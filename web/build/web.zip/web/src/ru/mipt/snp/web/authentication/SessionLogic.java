package ru.mipt.snp.web.authentication;

/**
 * <p></p>
 *
 * @author Kirill Tsibriy
 * @since Feb 16, 2009 12:03:13 PM
 */
public interface SessionLogic {
    boolean isLoggedIn();
}
