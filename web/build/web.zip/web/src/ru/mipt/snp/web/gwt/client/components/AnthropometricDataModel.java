package ru.mipt.snp.web.gwt.client.components;

import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * <p></p>
 *
 * @author Maxim Galushka
 * @since 03/13/2009  17:23
 */
public class AnthropometricDataModel implements IsSerializable{

    private String growth;
    private String weight;
    private String neckGirth;
    private String bicepsGirth;
    private String chestGirth;
    private String waistGirth;
    private String thighGirth;
    private String drumstickGirth;

    public AnthropometricDataModel() {
    }

    public AnthropometricDataModel(String growth, String weight, String neckGirth,
                                   String bicepsGirth, String chestGirth, String waistGirth,
                                   String thighGirth, String drumstickGirth) {
        this.growth = growth;
        this.weight = weight;
        this.neckGirth = neckGirth;
        this.bicepsGirth = bicepsGirth;
        this.chestGirth = chestGirth;
        this.waistGirth = waistGirth;
        this.thighGirth = thighGirth;
        this.drumstickGirth = drumstickGirth;
    }

    public String getGrowth() {
        return growth;
    }

    public void setGrowth(String growth) {
        this.growth = growth;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getNeckGirth() {
        return neckGirth;
    }

    public void setNeckGirth(String neckGirth) {
        this.neckGirth = neckGirth;
    }

    public String getBicepsGirth() {
        return bicepsGirth;
    }

    public void setBicepsGirth(String bicepsGirth) {
        this.bicepsGirth = bicepsGirth;
    }

    public String getChestGirth() {
        return chestGirth;
    }

    public void setChestGirth(String chestGirth) {
        this.chestGirth = chestGirth;
    }

    public String getWaistGirth() {
        return waistGirth;
    }

    public void setWaistGirth(String waistGirth) {
        this.waistGirth = waistGirth;
    }

    public String getThighGirth() {
        return thighGirth;
    }

    public void setThighGirth(String thighGirth) {
        this.thighGirth = thighGirth;
    }

    public String getDrumstickGirth() {
        return drumstickGirth;
    }

    public void setDrumstickGirth(String drumstickGirth) {
        this.drumstickGirth = drumstickGirth;
    }
}
