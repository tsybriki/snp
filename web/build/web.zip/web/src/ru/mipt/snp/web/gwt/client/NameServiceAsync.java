package ru.mipt.snp.web.gwt.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * <p></p>
 *
 * @author Kirill Tsibriy
 * @since Feb 16, 2009 1:23:11 PM
 */
public interface NameServiceAsync {
    void getName(AsyncCallback<String> callback);
}
