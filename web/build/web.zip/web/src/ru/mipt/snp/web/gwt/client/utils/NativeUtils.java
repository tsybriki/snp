package ru.mipt.snp.web.gwt.client.utils;

/**
 * <p>Native javascript utility class</p>
 *
 * @author Maxim Galushka
 * @since 03/12/2009  14:13
 */
public final class NativeUtils {

    /**
     * Redirects browser window to specified URL
     * @param url URL where to redirect 
     */
    native public static void redirect(String url)
/*-{
        $wnd.location.replace(url);
}-*/; 

}
