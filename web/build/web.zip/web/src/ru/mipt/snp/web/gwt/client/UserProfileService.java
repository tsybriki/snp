package ru.mipt.snp.web.gwt.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import ru.mipt.snp.web.gwt.client.models.UserSettingsModel;
import ru.mipt.snp.web.gwt.client.components.UserPasswordModel;

/**
 * <p>Service which provides server side operations on user profile</p>
 *
 * @author Maxim Galushka
 * @since 03/05/2009  14:01
 */
@RemoteServiceRelativePath("rpc/userProfileService.rpc")
public interface UserProfileService extends RemoteService {

    void updateUserSettings(UserSettingsModel data);

    UserSettingsModel getUserSettings();

    void updateUserPassword(UserPasswordModel passwordModel);

    UserPasswordModel getUserPasswordModel();
}
