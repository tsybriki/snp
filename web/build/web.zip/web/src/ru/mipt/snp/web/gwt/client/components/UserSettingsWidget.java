package ru.mipt.snp.web.gwt.client.components;

import com.google.code.p.gwtchismes.client.GWTCButton;
import com.google.code.p.gwtchismes.client.GWTCDatePicker;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.*;
import ru.mipt.snp.web.gwt.client.LoginMessages;
import ru.mipt.snp.web.gwt.client.UserProfileService;
import ru.mipt.snp.web.gwt.client.UserProfileServiceAsync;
import ru.mipt.snp.web.gwt.client.ApplicationMessages;
import ru.mipt.snp.web.gwt.client.models.UserSettingsModel;
import ru.mipt.snp.web.gwt.client.utils.ComponentUtils;
import ru.mipt.snp.web.gwt.client.utils.ValidateUtils;

import java.util.Date;

/**
 * <p>User settings panel widget</p>
 *
 * @author Maxim Galushka
 * @since 03/05/2009  12:16
 */
public class UserSettingsWidget extends DecoratorPanel {

    private static final String HORIZONTAL_LINE_CODE = "<hr/>";
    private static final String EMPTY_STRING = "";
    private static final String GENDER_GROUP_NAME = "gender";
    private static final String DATE_FORMAT = "d MMMM yyyy";

    public static final LoginMessages messages = GWT.create(LoginMessages.class);
    public static final ApplicationMessages appMessages = GWT.create(ApplicationMessages.class);
    final UserProfileServiceAsync service = (UserProfileServiceAsync) GWT.create(UserProfileService.class);

    private TextBox firstNameTextBox;
    private TextBox lastNameTextBox;
    private RadioButton genderMaleButton;
    private RadioButton genderFemaleButton;
    private TextBox dateOfBirthTextBox;

    private TextBox oldPasswordTextBox;
    private TextBox newPasswordTextBox;
    private TextBox repeatNewPasswordTextBox;

    private FlexTable layout;
    private FlexTable.FlexCellFormatter cellFormatter;

    public UserSettingsWidget() {

        layout = new FlexTable();
        layout.setCellSpacing(6);
//        layout.setBorderWidth(1);
        cellFormatter = layout.getFlexCellFormatter();

        int rowNumber = -1;

        // User settings section
        layout.setHTML(++rowNumber, 0, messages.settingsTitle());
        cellFormatter.setColSpan(rowNumber, 0, 2);
        cellFormatter.setHorizontalAlignment(rowNumber, 0, HasHorizontalAlignment.ALIGN_CENTER);

        // first/last name
        firstNameTextBox = updateLayout(++rowNumber, messages.settingsFirstName(), false);
        lastNameTextBox = updateLayout(++rowNumber, messages.settingsLastName(), false);

        // gender panel
        layout.setHTML(++rowNumber, 0, messages.settingsGender());
        HorizontalPanel genderPanel = new HorizontalPanel();
        genderMaleButton = new RadioButton(GENDER_GROUP_NAME, messages.settingsMale());
        genderFemaleButton = new RadioButton(GENDER_GROUP_NAME, messages.settingsFemale());
        genderMaleButton.setChecked(true);
        genderPanel.add(genderMaleButton);
        genderPanel.add(genderFemaleButton);
        cellFormatter.setHorizontalAlignment(rowNumber, 1, HasHorizontalAlignment.ALIGN_LEFT);
        layout.setWidget(rowNumber, 1, genderPanel);

        // date of birth panel
        layout.setHTML(++rowNumber, 0, messages.settingsDateOfBirth());
        final HorizontalPanel dateOfBirthPanel = new HorizontalPanel();
        dateOfBirthTextBox = ComponentUtils.buildStandardTextBox(15, false);
        final GWTCButton showCalendarButton = new GWTCButton(EMPTY_STRING);
        showCalendarButton.setImageSrc("images/gwtc-calendar.gif");
        showCalendarButton.addClickListener(new ClickListener() {
            public void onClick(Widget sender) {
                createCalendarPicker(showCalendarButton, dateOfBirthTextBox);
            }
        });
        dateOfBirthPanel.add(dateOfBirthTextBox);
        dateOfBirthPanel.add(showCalendarButton);
        cellFormatter.setHorizontalAlignment(rowNumber, 1, HasHorizontalAlignment.ALIGN_LEFT);
        layout.setWidget(rowNumber, 1, dateOfBirthPanel);


        // save button
        cellFormatter.setColSpan(++rowNumber, 0, 2);
        Button saveButton = buildSettingsSaveButton();
        cellFormatter.setHorizontalAlignment(rowNumber, 0, HasHorizontalAlignment.ALIGN_RIGHT);
        layout.setWidget(rowNumber, 0, saveButton);

        // horizontal separator
        cellFormatter.setColSpan(++rowNumber, 0, 2);
        cellFormatter.setHorizontalAlignment(rowNumber, 0, HasHorizontalAlignment.ALIGN_CENTER);
        layout.setHTML(rowNumber, 0, HORIZONTAL_LINE_CODE);

        // Change password section
        layout.setHTML(++rowNumber, 0, messages.settingsChangePassword());
        cellFormatter.setColSpan(rowNumber, 0, 2);
        cellFormatter.setHorizontalAlignment(rowNumber, 0, HasHorizontalAlignment.ALIGN_CENTER);

        oldPasswordTextBox = updateLayout(++rowNumber, messages.settingsOldPassword(), true);
        newPasswordTextBox = updateLayout(++rowNumber, messages.settingsNewPassword(), true);
        repeatNewPasswordTextBox = updateLayout(++rowNumber, messages.settingsNewPassword(), true);

        cellFormatter.setColSpan(++rowNumber, 0, 2);
        Button savePasswordButton = buildUpdatePasswordButton();
        cellFormatter.setHorizontalAlignment(rowNumber, 0, HasHorizontalAlignment.ALIGN_CENTER);
        layout.setWidget(rowNumber, 0, savePasswordButton);

        this.setWidget(layout);

    }

    @Override
    protected void onLoad() {
        service.getUserSettings(new AsyncCallback<UserSettingsModel>() {
            public void onFailure(Throwable caught) {
                Window.alert(messages.settingsErrorLoadingSettingsFromDatabase());
            }

            public void onSuccess(UserSettingsModel model) {
                firstNameTextBox.setText(model.getFirstName());
                firstNameTextBox.setEnabled(true);
                lastNameTextBox.setText(model.getLastName());
                lastNameTextBox.setEnabled(true);
            }
        });
    }

    private TextBox updateLayout(int rowNumber, String nameLabel, boolean isPassword){
        layout.setHTML(rowNumber, 0, nameLabel);
        TextBox controlTextBox = ComponentUtils.buildStandardTextBox(null, isPassword);
        cellFormatter.setHorizontalAlignment(rowNumber, 1, HasHorizontalAlignment.ALIGN_LEFT);
        layout.setWidget(rowNumber, 1, controlTextBox);
        return controlTextBox;
    }

    private void createCalendarPicker(Widget calendarButton, final TextBox dateTextBox) {
        int options = GWTCDatePicker.CONFIG_DIALOG | GWTCDatePicker.CONFIG_STANDARD_BUTTONS |
                      GWTCDatePicker.CONFIG_NO_ANIMATION | GWTCDatePicker.CONFIG_NO_CLOSE_BUTTON |
                      GWTCDatePicker.CONFIG_NO_HELP_BUTTON;
        final GWTCDatePicker picker = new GWTCDatePicker(options);
        picker.setText(messages.settingsCalendar());
        picker.setMaximalDate(GWTCDatePicker.increaseDate(new Date(), 0));
        picker.setMinimalDate(GWTCDatePicker.increaseYear(new Date(), -200));
        picker.addChangeListener(new ChangeListener() {
            public void onChange(Widget sender) {
                dateTextBox.setText(((GWTCDatePicker) sender).getSelectedDateStr(DATE_FORMAT));
            }
        });

        picker.show(calendarButton);
    }

    private Button buildSettingsSaveButton(){
        return new Button(messages.settingsSaveButtonLabel(), new ClickListener(){
            public void onClick(Widget sender) {
                String firstName = firstNameTextBox.getText();
                String lastName = lastNameTextBox.getText();
                if(!ValidateUtils.validateNotEmptyString(firstName, messages.settingsFirstName()) ||
                   !ValidateUtils.validateNotEmptyString(lastName, messages.settingsLastName())){
                    return;
                }

                UserSettingsModel model = new UserSettingsModel(firstName, lastName);

                service.updateUserSettings(model, new AsyncCallback() {
                    public void onFailure(Throwable caught) {
                        Window.alert(messages.settingsSavedErrorMessage());
                    }
                    public void onSuccess(Object result) {
                        Window.alert(messages.settingsSavedMessage());
                    }
                });
            }
        });
    }

    private Button buildUpdatePasswordButton(){
        return new Button(messages.settingsSaveNewPasswordLabel(), new ClickListener(){
            public void onClick(Widget sender) {
                String oldPassword = oldPasswordTextBox.getText();
                String newPassword = newPasswordTextBox.getText();
                String repeatNewPassword = repeatNewPasswordTextBox.getText();

                if(!ValidateUtils.validateNotEmptyString(oldPassword, messages.settingsOldPassword()) ||
                   !ValidateUtils.validateNotEmptyString(newPassword, messages.settingsNewPassword()) ||
                   !ValidateUtils.validateNotEmptyString(repeatNewPassword, messages.settingsRepeatNewPassword()) ||
                   !ValidateUtils.validatePasswordsMismatch(newPassword, repeatNewPassword)){
                    return;
                }

                final UserPasswordModel model = new UserPasswordModel(oldPassword, newPassword, repeatNewPassword);
                service.getUserPasswordModel(new AsyncCallback<UserPasswordModel>() {
                    public void onFailure(Throwable caught) {
                        Window.alert(messages.settingsSavedPasswordErrorMessage());
                    }

                    public void onSuccess(UserPasswordModel result) {
                        if(!model.getOldPassword().equals(result.getNewPassword())){
                            Window.alert(messages.settingsOldPasswordIncorrectError());
                        }
                        else{
                            service.updateUserPassword(model, new AsyncCallback() {
                                public void onFailure(Throwable caught) {
                                    Window.alert(messages.settingsSavedPasswordErrorMessage());
                                }

                                public void onSuccess(Object result) {
                                    Window.alert(messages.settingsPasswordSuccessfullySavedMessage());
                                    oldPasswordTextBox.setText(EMPTY_STRING);
                                    newPasswordTextBox.setText(EMPTY_STRING);
                                    repeatNewPasswordTextBox.setText(EMPTY_STRING);
                                }
                            });
                        }
                    }
                });
            }
        });
    }

}


