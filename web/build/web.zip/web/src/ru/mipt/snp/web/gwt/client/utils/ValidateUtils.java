package ru.mipt.snp.web.gwt.client.utils;

import com.google.gwt.user.client.Window;
import com.google.gwt.core.client.GWT;
import ru.mipt.snp.web.gwt.client.LoginMessages;

/**
 * <p></p>
 *
 * @author Maxim Galushka
 * @since 03/12/2009  17:51
 */
public final class ValidateUtils {

    public static final LoginMessages messages = GWT.create(LoginMessages.class);

    public static boolean validateNotEmptyString(String input, String fieldName){
        if(input == null || input.trim().length() == 0){
            Window.alert(messages.settingsEmptyFormFieldError(fieldName));
            return false;
        }
        return true;
    }

    public static boolean validatePasswordsMismatch(String newPassword, String confirmNewPassword){
        if(!newPassword.equals(confirmNewPassword)){
            Window.alert(messages.settingsPasswordsMismatchError());
            return false;
        }
        return true;
    }
}
