package ru.mipt.snp.web.authentication;

import ru.mipt.snp.domain.User;

/**
 * <p>Class used to store details in session</p>
 *
 * @author Kirill Tsibriy
 * @since Feb 16, 2009 12:02:51 PM
 */
public class UserSession {
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
